fn main() {
    regulator::run();
}
